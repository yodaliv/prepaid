<?php $__env->startSection('content'); ?>
<section id="home-section-1" class="container shadow">
    <div class="row">
        <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-lx-4 home-left-bg-styling">
            <div class="py-4 px-4 text-white">
                <h2 class="pt-5 pb-3 px-4 text-white wow animated fadeIn">Your online mobile recharge transaction is completely guaranteed</h2>
                <ul class="list-unstyled">
                    <li class="list-inline-item">
                        <img src="<?php echo e(asset('frontend/img/facebook-social-icon.png')); ?>" alt="facebook" class="img-fluid home-social-icon  wow animated fadeInUp">
                    </li>
                    <li class="list-inline-item">
                        <img src="<?php echo e(asset('frontend/img/twitter-social-icon.png')); ?>" alt="twitter" class="img-fluid home-social-icon  wow animated fadeInUp">
                    </li>
                    <li class="list-inline-item">
                        <img src="<?php echo e(asset('frontend/img/gmail-social-icon.png')); ?>" alt="" class="img-fluid home-social-icon  wow animated fadeInUp">
                    </li>
                    <li class="list-inline-item">
                        <img src="<?php echo e(asset('frontend/img/instgram-social-icon.png')); ?>" alt="" class="img-fluid home-social-icon  wow animated fadeInUp">
                    </li>
                    <li class="list-inline-item">
                        <img src="<?php echo e(asset('frontend/img/whatsapp-social-icon.png')); ?>" alt="" class="img-fluid home-social-icon  wow animated fadeInUp">
                    </li>
                </ul>
            </div>
        </div>
        <div class="col-12 col-sm-12 col-md-8 col-lg-8 col-lx-8 py-5 px-4 bg-white montserrat-bold">
            <div class="row  mt-4">
                <div class="col-12 col-6 col-md-6 col-lg-6 col-lx-6">
                    <div class="row">
                        <div class="col-3">
                            <img src="<?php echo e(asset('frontend/img/home-page-low-icon.png')); ?>" alt="" class="img-fluid  wow animated fadeInLeft">
                        </div>
                        <div class="col-9">
                            <h3 class="text-dark mb-3">Low Cost</h3>
                            <p class="color-gray font-12 text-left  wow animated fadeIn">Integer feugiat eros ut sapien auctor porta. Nulla vitae dolor quis elit porttitor lacinia a a felis.</p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-6 col-md-6 col-lg-6 col-lx-6">
                    <div class="row">
                        <div class="col-3">
                            <img src="<?php echo e(asset('frontend/img/home-page-super-icon.png')); ?>" alt="" class="img-fluid  wow animated fadeInLeft">
                        </div>
                        <div class="col-9">
                            <h3 class="text-dark mb-3">Super Fast</h3>
                            <p class="color-gray font-12 text-left  wow animated fadeIn">Integer feugiat eros ut sapien auctor porta. Nulla vitae dolor quis elit porttitor lacinia a a felis.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-6 col-md-6 col-lg-6 col-lx-6">
                    <div class="row">
                        <div class="col-3">
                            <img src="<?php echo e(asset('frontend/img/home-page-simple-icon.png')); ?>" alt="" class="img-fluid  wow animated fadeInLeft">
                        </div>
                        <div class="col-9">
                            <h3 class="text-dark mb-3">Simple</h3>
                            <p class="color-gray font-12 text-left  wow animated fadeIn">Integer feugiat eros ut sapien auctor porta. Nulla vitae dolor quis elit porttitor lacinia a a felis.</p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-6 col-md-6 col-lg-6 col-lx-6">
                    <div class="row">
                        <div class="col-3">
                            <img src="<?php echo e(asset('frontend/img/home-page-trust-icon.png')); ?>" alt="" class="img-fluid  wow animated fadeInLeft">
                        </div>
                        <div class="col-9">
                            <h3 class="text-dark mb-3">Trusted</h3>
                            <p class="color-gray font-12 text-left  wow animated fadeIn">Integer feugiat eros ut sapien auctor porta. Nulla vitae dolor quis elit porttitor lacinia a a felis.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 mt-4">
                    <ul class="list-unstyled text-center">
                        <li class="list-inline-item"><img src="<?php echo e(asset('frontend/img/partner-1.jpeg')); ?>" alt="partners"
                                                          class="img-fluid home-social-icon  wow animated fadeInUp"></li>
                        <li class="list-inline-item"><img src="<?php echo e(asset('frontend/img/partner-2.jpeg')); ?>" alt="partners"
                                                          class="img-fluid home-social-icon  wow animated fadeInUp"></li>
                        <li class="list-inline-item"><img src="<?php echo e(asset('frontend/img/partner-3.jpeg')); ?>" alt="partners"
                                                          class="img-fluid home-social-icon  wow animated fadeInUp"></li>
                        <li class="list-inline-item"><img src="<?php echo e(asset('frontend/img/partner-4.jpeg')); ?>" alt="partners" class="img-fluid home-social-icon  wow animated fadeInUp"></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work_Projects\prepaid\resources\views/home.blade.php ENDPATH**/ ?>