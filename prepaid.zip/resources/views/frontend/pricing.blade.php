@extends('layouts.app')

@section('content')
<section id="contact" class="py-5">
    <div class="container">
        <h1 class="text-capitalize color-primary mb-5 wow fadeIn animated">pricing</h1>
    </div>
</section>
@endsection
